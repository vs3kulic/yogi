import * as uri from "fast-uri";
type URI = typeof uri & {
    code: string;
};
declare const _default: URI;
export default _default;
