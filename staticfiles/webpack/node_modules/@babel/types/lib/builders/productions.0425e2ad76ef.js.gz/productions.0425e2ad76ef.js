"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.buildUndefinedNode = buildUndefinedNode;
var _index = require("./generated/index.js");
function buildUndefinedNode() {
  return (0, _index.unaryExpression)("void", (0, _index.numericLiteral)(0), true);
}

//# sourceMappingURL=productions.js.map
