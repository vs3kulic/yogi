"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classPrivateFieldSet2;
var _assertClassBrand = require("./assertClassBrand.js");
function _classPrivateFieldSet2(privateMap, receiver, value) {
  privateMap.set((0, _assertClassBrand.default)(privateMap, receiver), value);
  return value;
}

//# sourceMappingURL=classPrivateFieldSet2.js.map
