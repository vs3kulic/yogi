"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classNameTDZError;
function _classNameTDZError(name) {
  throw new ReferenceError('Class "' + name + '" cannot be referenced in computed property keys.');
}

//# sourceMappingURL=classNameTDZError.js.map
