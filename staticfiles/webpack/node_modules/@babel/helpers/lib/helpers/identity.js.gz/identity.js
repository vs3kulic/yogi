"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _identity;
function _identity(x) {
  return x;
}

//# sourceMappingURL=identity.js.map
