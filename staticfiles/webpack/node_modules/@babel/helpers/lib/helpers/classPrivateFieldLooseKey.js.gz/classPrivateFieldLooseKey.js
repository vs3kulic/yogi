"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classPrivateFieldKey;
var id = 0;
function _classPrivateFieldKey(name) {
  return "__private_" + id++ + "_" + name;
}

//# sourceMappingURL=classPrivateFieldLooseKey.js.map
