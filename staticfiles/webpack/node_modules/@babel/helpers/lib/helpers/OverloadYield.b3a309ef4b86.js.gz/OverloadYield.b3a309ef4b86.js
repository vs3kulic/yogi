"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _OverloadYield;
function _OverloadYield(value, kind) {
  this.v = value;
  this.k = kind;
}

//# sourceMappingURL=OverloadYield.js.map
