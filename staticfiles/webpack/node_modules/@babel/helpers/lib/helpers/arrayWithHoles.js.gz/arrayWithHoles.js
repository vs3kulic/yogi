"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _arrayWithHoles;
function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

//# sourceMappingURL=arrayWithHoles.js.map
