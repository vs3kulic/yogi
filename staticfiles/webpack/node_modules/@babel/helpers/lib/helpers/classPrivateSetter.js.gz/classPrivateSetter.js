"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classPrivateSetter;
var _assertClassBrand = require("./assertClassBrand.js");
function _classPrivateSetter(privateMap, setter, receiver, value) {
  setter((0, _assertClassBrand.default)(privateMap, receiver), value);
  return value;
}

//# sourceMappingURL=classPrivateSetter.js.map
