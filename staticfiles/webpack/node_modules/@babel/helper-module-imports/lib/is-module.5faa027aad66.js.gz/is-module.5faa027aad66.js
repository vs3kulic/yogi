"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = isModule;
function isModule(path) {
  return path.node.sourceType === "module";
}

//# sourceMappingURL=is-module.js.map
