const set = require('regenerate')();
set.addRange(0x964, 0x965).addRange(0xA830, 0xA839).addRange(0x11680, 0x116B9).addRange(0x116C0, 0x116C9);
exports.characters = set;
