import type { LoaderDefinitionFunction } from 'webpack';
declare const StylePostLoader: LoaderDefinitionFunction;
export default StylePostLoader;
