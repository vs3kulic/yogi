import type { LoaderDefinitionFunction } from 'webpack';
declare const StyleInineLoader: LoaderDefinitionFunction;
export default StyleInineLoader;
