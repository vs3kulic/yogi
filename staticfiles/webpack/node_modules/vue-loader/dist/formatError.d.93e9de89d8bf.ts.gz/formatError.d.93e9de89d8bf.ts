import type { CompilerError } from 'vue/compiler-sfc';
export declare function formatError(err: SyntaxError | CompilerError, source: string, file: string): void;
