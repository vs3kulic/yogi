import type { LoaderDefinitionFunction } from 'webpack';
declare const TemplateLoader: LoaderDefinitionFunction;
export default TemplateLoader;
