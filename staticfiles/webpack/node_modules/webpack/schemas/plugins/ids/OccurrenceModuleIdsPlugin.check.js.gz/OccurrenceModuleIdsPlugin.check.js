/*
 * This file was automatically generated.
 * DO NOT MODIFY BY HAND.
 * Run `yarn fix:special` to update
 */
"use strict";function r(t,{instancePath:e="",parentData:o,parentDataProperty:a,rootData:i=t}={}){if(!t||"object"!=typeof t||Array.isArray(t))return r.errors=[{params:{type:"object"}}],!1;{const e=0;for(const e in t)if("prioritiseInitial"!==e)return r.errors=[{params:{additionalProperty:e}}],!1;if(0===e&&void 0!==t.prioritiseInitial&&"boolean"!=typeof t.prioritiseInitial)return r.errors=[{params:{type:"boolean"}}],!1}return r.errors=null,!0}module.exports=r,module.exports.default=r;