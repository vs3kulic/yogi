Users/vajosekulic/Documents/Programming/Yogi/static/webpack/babel.config.js
module.exports = {
  presets: [
    ['@babel/preset-env', { useBuiltIns: 'usage', corejs: 3 }]
  ]
}