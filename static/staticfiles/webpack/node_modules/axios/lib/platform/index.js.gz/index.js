import platform from './node/index.js';
import * as utils from './common/utils.js';

export default {
  ...utils,
  ...platform
}
