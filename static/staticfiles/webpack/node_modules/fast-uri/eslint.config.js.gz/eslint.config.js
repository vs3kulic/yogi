'use strict'

module.exports = require('neostandard')({
  ignores: require('neostandard').resolveIgnoresFromGitignore(),
  ts: true
})
