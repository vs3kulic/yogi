"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = _classExtractFieldDescriptor;
var _classPrivateFieldGet = require("classPrivateFieldGet2");
function _classExtractFieldDescriptor(receiver, privateMap) {
  return _classPrivateFieldGet(privateMap, receiver);
}

//# sourceMappingURL=classExtractFieldDescriptor.js.map
