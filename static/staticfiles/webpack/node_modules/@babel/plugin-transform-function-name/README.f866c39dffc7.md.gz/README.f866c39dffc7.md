# @babel/plugin-transform-function-name

> Apply ES2015 function.name semantics to all functions

See our website [@babel/plugin-transform-function-name](https://babeljs.io/docs/babel-plugin-transform-function-name) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-function-name
```

or using yarn:

```sh
yarn add @babel/plugin-transform-function-name --dev
```
