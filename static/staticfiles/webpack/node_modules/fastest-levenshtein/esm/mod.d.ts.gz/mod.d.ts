declare const distance: (a: string, b: string) => number;
declare const closest: (str: string, arr: readonly string[]) => string;
export { closest, distance };
//# sourceMappingURL=mod.d.ts.map