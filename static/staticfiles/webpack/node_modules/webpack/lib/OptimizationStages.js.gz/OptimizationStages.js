/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Florent Cailhol @ooflorent
*/

"use strict";

module.exports.STAGE_BASIC = -10;
module.exports.STAGE_DEFAULT = 0;
module.exports.STAGE_ADVANCED = 10;
