import type { LoaderDefinitionFunction } from 'webpack';
declare const pitcher: LoaderDefinitionFunction;
export declare const pitch: () => string | undefined;
export default pitcher;
