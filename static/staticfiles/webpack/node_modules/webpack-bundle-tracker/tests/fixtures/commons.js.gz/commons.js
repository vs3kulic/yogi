'use strict';

const assign = require('lodash.assign');

const output = { name: '' };

assign(output, { name: 'common' });

module.exports = output;
